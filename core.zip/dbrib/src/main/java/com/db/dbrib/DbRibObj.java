package com.db.dbrib;

import java.util.Date;
import java.util.List;

public class DbRibObj {
    String chgNo;
    List<String> CIs;
    Date startDateTime;
    Date endDateTime;
    String summary;
    String impact;

    public String getChgNo() {
        return chgNo;
    }

    public void setChgNo(String chgNo) {
        this.chgNo = chgNo;
    }

    public List<String> getCIs() {
        return CIs;
    }

    public void setCIs(List<String> cIs) {
        CIs = cIs;
    }

    public Date getStartDateTime() {
        return startDateTime;
    }

    public void setStartDateTime(Date startDateTime) {
        this.startDateTime = startDateTime;
    }

    public Date getEndDateTime() {
        return endDateTime;
    }

    public void setEndDateTime(Date endDateTime) {
        this.endDateTime = endDateTime;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getImpact() {
        return impact;
    }

    public void setImpact(String impact) {
        this.impact = impact;
    }

    @Override
    public String toString() {
        return "DbRibObj [CIs=" + CIs + ", chgNo=" + chgNo + ", endDateTime=" + endDateTime + ", impact=" + impact
                + ", startDateTime=" + startDateTime + ", summary=" + summary + "]";
    }

}