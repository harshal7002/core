package com.db.dbrib;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.DateFormatSymbols;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

@SpringBootApplication
public class DbribApplication implements CommandLineRunner {
	public static void main(String[] args) {
		SpringApplication.run(DbribApplication.class, args);
	}

	@Autowired
	DbRibProps props;

	HashMap<String, DbRibObj> dbRibMap = new HashMap<String, DbRibObj>();
	HashMap<String, DbRibObj> fmtdbRibMap = new HashMap<String, DbRibObj>();
	HashMap<String, List<DbRibObj>> monthlydbRibMap = new HashMap<String, List<DbRibObj>>();

	@Override
	public void run(String... args) throws Exception {
		generateFmtDbRibMap();
		generateDbRibMap();
		generateMonthlyDbRib();
		updateFmtDbRib();
	}

	public void generateMonthlyDbRib() {
		for (String key : dbRibMap.keySet()) {
			String month = "SHEET";
			DateFormatSymbols dfs = new DateFormatSymbols();
			String[] months = dfs.getMonths();
			month = months[dbRibMap.get(key).getStartDateTime().getMonth()];
			System.out.println("Month = " + month);
			if (!monthlydbRibMap.containsKey(month)) {
				List<DbRibObj> dbRibObj = new ArrayList<>();
				dbRibObj.add(dbRibMap.get(key));
				monthlydbRibMap.put(month, dbRibObj);
			} else {
				List<DbRibObj> dbRibObj = monthlydbRibMap.get(month);
				dbRibObj.add(dbRibMap.get(key));
				monthlydbRibMap.put(month, dbRibObj);
			}
		}
	}

	public void generateFmtDbRibMap() {
		try {
			File fmtfile = new File(props.getFmtDbRib());
			FileInputStream dbRibFmtfis = new FileInputStream(fmtfile);
			XSSFWorkbook dbRibFmtwb = new XSSFWorkbook(dbRibFmtfis);
			List<String> sheetNames = new ArrayList<String>();
			for (int i = 0; i < dbRibFmtwb.getNumberOfSheets(); i++) {
				sheetNames.add(dbRibFmtwb.getSheetName(i));
			}
			for (String name : sheetNames) {
				XSSFSheet sheet = dbRibFmtwb.getSheet(name);
				for (Row row : sheet) {
					if (row.getRowNum() > 0 && row.getCell(0) != null) {
						String dbRibChgNum = row.getCell(props.getDbRibChgNumColNo()).toString().toUpperCase();
						String dbRibCI = row.getCell(props.getDbRibCIColNo()).toString();
						Date dbRibStartDate = row.getCell(props.getDbRibStartDateColNo()).getDateCellValue();
						Date dbRibEndDate = row.getCell(props.getDbRibEndDateColNo()).getDateCellValue();
						String dbRibSummary = row.getCell(props.getDbRibSummaryColNo()).toString();
						String dbRibImpact = row.getCell(props.getDbRibImpactColNo()).toString();
						DbRibObj dbRibObj = new DbRibObj();
						dbRibObj.setChgNo(dbRibChgNum);

						List<String> dbRibCIObj = new ArrayList<String>();
						dbRibCIObj.add(dbRibCI);
						dbRibObj.setCIs(dbRibCIObj);

						dbRibObj.setStartDateTime(dbRibStartDate);
						dbRibObj.setEndDateTime(dbRibEndDate);
						dbRibObj.setSummary(dbRibSummary);
						dbRibObj.setImpact(dbRibImpact);
						fmtdbRibMap.put(dbRibChgNum, dbRibObj);
					}
				}
			}
			for (String key : fmtdbRibMap.keySet()) {
				System.out.println("Formated ::------ \n" + fmtdbRibMap.get(key).toString());
			}
			dbRibFmtfis.close();
			dbRibFmtwb.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void generateDbRibMap() {
		try {
			File file = new File(props.getDbRib());
			FileInputStream dbRibfis = new FileInputStream(file);
			XSSFWorkbook dbRibwb = new XSSFWorkbook(dbRibfis);
			XSSFSheet sheet = dbRibwb.getSheetAt(0);
			for (Row row : sheet) {
				if (row.getRowNum() > 0 && row.getCell(0) != null) {
					String dbRibChgNum = row.getCell(props.getDbRibChgNumColNo()).toString().toUpperCase();
					if (!isExistsInFmtSheet(dbRibChgNum)) {
						String dbRibCI = row.getCell(props.getDbRibCIColNo()).toString();
						if (!dbRibMap.containsKey(dbRibChgNum)) {
							Date dbRibStartDate = row.getCell(props.getDbRibStartDateColNo()).getDateCellValue();
							Date dbRibEndDate = row.getCell(props.getDbRibEndDateColNo()).getDateCellValue();
							String dbRibSummary = row.getCell(props.getDbRibSummaryColNo()).toString();
							String dbRibImpact = row.getCell(props.getDbRibImpactColNo()).toString();
							DbRibObj dbRibObj = new DbRibObj();
							dbRibObj.setChgNo(dbRibChgNum);

							List<String> dbRibCIObj = new ArrayList<String>();
							dbRibCIObj.add(dbRibCI);
							dbRibObj.setCIs(dbRibCIObj);

							dbRibObj.setStartDateTime(dbRibStartDate);
							dbRibObj.setEndDateTime(dbRibEndDate);
							dbRibObj.setSummary(dbRibSummary);
							dbRibObj.setImpact(dbRibImpact);
							dbRibMap.put(dbRibChgNum, dbRibObj);
						} else {
							DbRibObj dbRibObj = dbRibMap.get(dbRibChgNum);
							List<String> dbRibCIObj = dbRibObj.getCIs();
							dbRibCIObj.add(dbRibCI);
							dbRibObj.setCIs(dbRibCIObj);
						}
					}
				}
			}
			for (String key : dbRibMap.keySet()) {
				System.out.println(dbRibMap.get(key).toString());
			}
			dbRibfis.close();
			dbRibwb.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void updateFmtDbRib() {
		try {

			File fmtfile = new File(props.getFmtDbRib());
			FileInputStream dbRibFmtfis = new FileInputStream(fmtfile);
			XSSFWorkbook dbRibFmtwb = new XSSFWorkbook(dbRibFmtfis);
			CellStyle cs = dbRibFmtwb.createCellStyle();
			cs.setWrapText(true);
			CreationHelper creationHelper = dbRibFmtwb.getCreationHelper();
			CellStyle customDateFormat = dbRibFmtwb.createCellStyle();
			customDateFormat.setDataFormat(creationHelper.createDataFormat().getFormat("dd-mm-yyyy hh:mm"));

			for (String month : monthlydbRibMap.keySet()) {
				System.out.println("Month = " + month);

				XSSFSheet sheet = dbRibFmtwb.getSheet(month);
				List<Row> emptyRowsToDelete = new ArrayList<Row>();
				for (Row row : sheet) {
					if (row.getCell(0) == null) {
						emptyRowsToDelete.add(row);
					}
				}
				for (Row row : emptyRowsToDelete) {
					sheet.removeRow(row);
				}
				for (DbRibObj dbRibObj : monthlydbRibMap.get(month)) {
					Row row = sheet.createRow(sheet.getPhysicalNumberOfRows());
					Cell dbRibChgNum = row.createCell(props.getDbRibChgNumColNo());
					Cell dbRibCI = row.createCell(props.getDbRibCIColNo());
					Cell dbRibStartDate = row.createCell(props.getDbRibStartDateColNo());
					Cell dbRibEndDate = row.createCell(props.getDbRibEndDateColNo());
					Cell dbRibSummary = row.createCell(props.getDbRibSummaryColNo());
					Cell dbRibImpact = row.createCell(props.getDbRibImpactColNo());

					dbRibCI.setCellStyle(cs);
					dbRibChgNum.setCellValue(dbRibObj.getChgNo().toUpperCase());
					dbRibCI.setCellValue(String.join(", \n", dbRibObj.getCIs()));
					dbRibStartDate.setCellValue(dbRibObj.getStartDateTime());
					dbRibStartDate.setCellStyle(customDateFormat);
					dbRibEndDate.setCellValue(dbRibObj.getEndDateTime());
					dbRibEndDate.setCellStyle(customDateFormat);
					dbRibSummary.setCellValue(dbRibObj.getSummary());
					dbRibImpact.setCellValue(dbRibObj.getImpact());
					System.out.println(dbRibObj);
				}
			}

			dbRibFmtfis.close();
			FileOutputStream dbRibFmtfos = new FileOutputStream(fmtfile);
			dbRibFmtwb.write(dbRibFmtfos);
			dbRibFmtwb.close();
			dbRibFmtfos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean isExistsInFmtSheet(String chgNo) {
		boolean isExists = false;
		if (fmtdbRibMap.containsKey(chgNo)) {
			return true;
		}
		return isExists;
	}
}
