package com.db.dbrib;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@PropertySource("application.properties")
@Configuration
public class DbRibProps {

    @Value("${file.path.dbRib}")
    private String dbRib;

    @Value("${file.path.fmt.dbRib}")
    private String fmtDbRib;

    @Value("${dbRib.dbRibChgNumColNo}")
    private Integer dbRibChgNumColNo;

    @Value("${dbRib.dbRibCIColNo}")
    private Integer dbRibCIColNo;

    @Value("${dbRib.dbRibStartDateColNo}")
    private Integer dbRibStartDateColNo;

    @Value("${dbRib.dbRibEndDateColNo}")
    private Integer dbRibEndDateColNo;

    @Value("${dbRib.dbRibSummaryColNo}")
    private Integer dbRibSummaryColNo;

    @Value("${dbRib.dbRibImpactColNo}")
    private Integer dbRibImpactColNo;

    @Value("${dbRib.fmtDbRibChgNumColNo}")
    private Integer fmtDbRibChgNumColNo;

    @Value("${dbRib.fmtDbRibCIColNo}")
    private Integer fmtDbRibCIColNo;

    @Value("${dbRib.fmtDbRibStartDateColNo}")
    private Integer fmtDbRibStartDateColNo;

    @Value("${dbRib.fmtDbRibEndDateColNo}")
    private Integer fmtDbRibEndDateColNo;

    @Value("${dbRib.fmtDbRibSummaryColNo}")
    private Integer fmtDbRibSummaryColNo;

    @Value("${dbRib.fmtDbRibImpactColNo}")
    private Integer fmtDbRibImpactColNo;

    public String getDbRib() {
        return dbRib;
    }

    public String getFmtDbRib() {
        return fmtDbRib;
    }

    public Integer getDbRibChgNumColNo() {
        return dbRibChgNumColNo;
    }

    public void setDbRibChgNumColNo(Integer dbRibChgNumColNo) {
        this.dbRibChgNumColNo = dbRibChgNumColNo;
    }

    public Integer getDbRibCIColNo() {
        return dbRibCIColNo;
    }

    public void setDbRibCIColNo(Integer dbRibCIColNo) {
        this.dbRibCIColNo = dbRibCIColNo;
    }

    public Integer getDbRibStartDateColNo() {
        return dbRibStartDateColNo;
    }

    public void setDbRibStartDateColNo(Integer dbRibStartDateColNo) {
        this.dbRibStartDateColNo = dbRibStartDateColNo;
    }

    public Integer getDbRibEndDateColNo() {
        return dbRibEndDateColNo;
    }

    public void setDbRibEndDateColNo(Integer dbRibEndDateColNo) {
        this.dbRibEndDateColNo = dbRibEndDateColNo;
    }

    public Integer getDbRibSummaryColNo() {
        return dbRibSummaryColNo;
    }

    public void setDbRibSummaryColNo(Integer dbRibSummaryColNo) {
        this.dbRibSummaryColNo = dbRibSummaryColNo;
    }

    public Integer getDbRibImpactColNo() {
        return dbRibImpactColNo;
    }

    public void setDbRibImpactColNo(Integer dbRibImpactColNo) {
        this.dbRibImpactColNo = dbRibImpactColNo;
    }

    public Integer getFmtDbRibChgNumColNo() {
        return fmtDbRibChgNumColNo;
    }

    public void setFmtDbRibChgNumColNo(Integer fmtDbRibChgNumColNo) {
        this.fmtDbRibChgNumColNo = fmtDbRibChgNumColNo;
    }

    public Integer getFmtDbRibCIColNo() {
        return fmtDbRibCIColNo;
    }

    public void setFmtDbRibCIColNo(Integer fmtDbRibCIColNo) {
        this.fmtDbRibCIColNo = fmtDbRibCIColNo;
    }

    public Integer getFmtDbRibStartDateColNo() {
        return fmtDbRibStartDateColNo;
    }

    public void setFmtDbRibStartDateColNo(Integer fmtDbRibStartDateColNo) {
        this.fmtDbRibStartDateColNo = fmtDbRibStartDateColNo;
    }

    public Integer getFmtDbRibEndDateColNo() {
        return fmtDbRibEndDateColNo;
    }

    public void setFmtDbRibEndDateColNo(Integer fmtDbRibEndDateColNo) {
        this.fmtDbRibEndDateColNo = fmtDbRibEndDateColNo;
    }

    public Integer getFmtDbRibSummaryColNo() {
        return fmtDbRibSummaryColNo;
    }

    public void setFmtDbRibSummaryColNo(Integer fmtDbRibSummaryColNo) {
        this.fmtDbRibSummaryColNo = fmtDbRibSummaryColNo;
    }

    public Integer getFmtDbRibImpactColNo() {
        return fmtDbRibImpactColNo;
    }

    public void setFmtDbRibImpactColNo(Integer fmtDbRibImpactColNo) {
        this.fmtDbRibImpactColNo = fmtDbRibImpactColNo;
    }

    @Override
    public String toString() {
        return "DbRibProps [dbRib=" + dbRib + ", dbRibCIColNo=" + dbRibCIColNo + ", dbRibChgNumColNo="
                + dbRibChgNumColNo + ", dbRibEndDateColNo=" + dbRibEndDateColNo + ", dbRibImpactColNo="
                + dbRibImpactColNo + ", dbRibStartDateColNo=" + dbRibStartDateColNo + ", dbRibSummaryColNo="
                + dbRibSummaryColNo + ", fmtDbRib=" + fmtDbRib + "]";
    }

}
